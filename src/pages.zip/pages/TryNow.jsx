import React from 'react'
import { useState } from 'react';
import CodeMirror from "@uiw/react-codemirror";
import { html } from "@codemirror/lang-html";
import { javascript } from "@codemirror/lang-javascript";
import { css } from "@codemirror/lang-css";

function TryNow() {

  const [activeTab, setActiveTab] = useState("html");
  const [htmlCode, setHtmlCode] = useState("<h1>Hello World!</h1>");
  const [cssCode, setCssCode] = useState("h1 { color: blue; }");
  const [jsCode, setJsCode] = useState("console.log('Hello JS!')");
  const [output, setOutput] = useState("");

  const runCode = () => {
    const combinedCode = `
      <html>
        <head>
          <style>${cssCode}</style>
        </head>
        <body>
          ${htmlCode}
          <script>${jsCode}</script>
        </body>
      </html>
    `;
    setOutput(combinedCode);
  };
  
  return (

  <div
      style={{
        display: "grid",
        gridTemplateColumns: "1fr 1fr",
        height: "100vh",
        backgroundColor: "#1e1e1e",
        color: "#fff",
      }}
    >
      {/* Left: Editor */}
      <div style={{ padding: "20px", display: "flex", flexDirection: "column" }}>
        <h2 style={{ marginBottom: "10px" }}>Code Editor</h2>

        {/* Tabs */}
        <div style={{ display: "flex", marginBottom: "10px" }}>
          {["html", "css", "js"].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              style={{
                flex: 1,
                background: activeTab === tab ? "#04AA6D" : "#333",
                color: "white",
                border: "none",
                padding: "10px",
                cursor: "pointer",
              }}
            >
              {tab.toUpperCase()}
            </button>
          ))}
        </div>

        
        {activeTab === "html" && (
          <CodeMirror
            value={htmlCode}
            height="400px"
            extensions={[html()]}
            theme="dark"
            onChange={(value) => setHtmlCode(value)}
          />
        )}
        {activeTab === "css" && (
          <CodeMirror
            value={cssCode}
            height="400px"
            extensions={[css()]}
            theme="dark"
            onChange={(value) => setCssCode(value)}
          />
        )}

        {activeTab === "js" && (
          <CodeMirror
            value={jsCode}
            height="400px"
            extensions={[javascript()]}
            theme="dark"
            onChange={(value) => setJsCode(value)}
          />
        )}

        <button
          onClick={runCode}
          style={{
            background: "#04AA6D",
            color: "white",
            border: "none",
            padding: "10px 20px",
            borderRadius: "5px",
            cursor: "pointer",
            marginTop: "15px",
          }}
        >
          Run ▶️
        </button>
      </div>

      {/* Right: Output */}
      <div style={{ padding: "20px", backgroundColor: "#fff" }}>
        <h2 style={{ color: "#000" }}>Result</h2>
        <iframe
          title="output"
          srcDoc={output}
          style={{
            width: "100%",
            height: "90%",
            border: "1px solid #ddd",
            borderRadius: "5px",
            background: "white",
          }}
          sandbox="allow-scripts"
        ></iframe>
      </div>
    </div>
  );
}

export default TryNow;