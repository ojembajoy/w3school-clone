import Examples from "../components/Examples";
import Hero from "../components/Hero";
import Tutorials from "../components/Tutorials";

const HomePage = () => {
    return (
        <div>
            <Hero />
           <Examples/>
                 <Tutorials/>
                 
        </div>
    );
};

export default HomePage;
