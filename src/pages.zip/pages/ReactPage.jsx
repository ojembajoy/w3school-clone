import theme from "prism-react-renderer/themes/dracula.js";
import copy from "copy-to-clipboard";
import React, { useState } from "react";
import { LiveProvider, LiveEditor, LiveError, LivePreview } from "react-live";
import styles from "./ReactPage.module.css";

const ReactPage = () => {
  const initialCode = `
() => {
  const [count, setCount] = React.useState(0);

  return (
    <div style={{
      textAlign: 'center',
      marginTop: '30px',
      fontFamily: 'Arial'
    }}>
      <h2>Hello React! 👋</h2>
      <p>Count: {count}</p>
      <button onClick={() => setCount(count + 1)}>Increase</button>
    </div>
  );
}
`;

  const [code, setCode] = useState(initialCode);
  const [key, setKey] = useState(0);

  const handleRun = () => setKey((prev) => prev + 1);
  const handleReset = () => setCode(initialCode);
  const handleCopy = () => copy(code);

  return (
    <div className={styles.mainContainer}>
      <h1>⚛️ React Page</h1>

      <div className={styles.buttons}>
        <button onClick={handleRun}>▶ Run</button>
        <button onClick={handleReset}>🔄 Reset</button>
        <button onClick={handleCopy}>📋 Copy</button>
      </div>

      <LiveProvider
        key={key}
        code={code}
        theme={theme}
        noInline={true}
        scope={{ React }}
      >
        <div className={styles.editorContainer}>
          <LiveEditor
            className={styles.editor}
            onChange={(newCode) => setCode(newCode)}
          />
          <div className={styles.previewBox}>
            <LivePreview className={styles.preview} />
            <LiveError className={styles.error} />
          </div>
        </div>
      </LiveProvider>
    </div>
  );
};

export default ReactPage;